// 引入面包屑导航组件
import NavBread from '@/components/NavBread'
// 导出组件
export default {
  components: {
    NavBread
  }
}
