<template>
  <footer class="footer">
    <div class="footer__wrap">
      <div class="footer__secondary">
        <div class="footer__inner">
          <div class="footer__region">
            <span>区域</span>
            <select class="footer__region__select">
              <option value="zh-CN">中国</option>
              <option value="en-US">美国</option>
            </select>
          </div>
          <div class="footer__secondary__nav">
            <span>Copyright © 2017 Dumall All Rights Reserved.</span>
            <a href="#"> 关于我们 </a>
            <a href="#"> 团队 &amp; 招聘 </a>
            <a href="#"> 协议 </a>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>
